This directory contains files that are useful both for building and
solving targets. 

FILES:

	gencookie.{h,c}

Generate 32-bit unique IDs.

	 gencode.{h,c}

Encodings of limited class of x86-64 instructions to be used when
building tarrets.

	 testgen.c

Testing code for gencode



